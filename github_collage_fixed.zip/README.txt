GITHUB PAGES — ЧТО ЗАГРУЖАТЬ

Загрузите в корень репозитория ДВА файла:
1. index.html
2. maket.png

Они должны лежать рядом, на одном уровне.

После этого:
Settings → Pages → Deploy from a branch → main → /(root) → Save

Не переименовывайте maket.png, если не меняете имя внутри index.html.
